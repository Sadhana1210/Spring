package com.example.demo.project;

public class Project {
 private String project_id,project_name,descrption,project_start,project_end,no_of_emp,Project_manager,project_hr,assignedby,id,status,joindate,firstname,lastname,role,usernam,dob,password,phone,email,zip,roleid,checkuser,checkpwd;
private String emp_id,newproject_name,project_copy_id;
public String getProject_copy_id() {
	return project_copy_id;
}

public void setProject_copy_id(String project_copy_id) {
	this.project_copy_id = project_copy_id;
}

public String getNewproject_name() {
	return newproject_name;
}

public void setNewproject_name(String newproject_name) {
	this.newproject_name = newproject_name;
}

public String getEmp_id() {
	return emp_id;
}

public void setEmp_id(String emp_id) {
	this.emp_id = emp_id;
}

public String getProject_id() {
	return project_id;
}

public void setProject_id(String project_id) {
	this.project_id = project_id;
}

public String getProject_name() {
	return project_name;
}

public void setProject_name(String project_name) {
	this.project_name = project_name;
}

public String getDescrption() {
	return descrption;
}

public void setDescrption(String descrption) {
	this.descrption = descrption;
}

public String getProject_start() {
	return project_start;
}

public void setProject_start(String project_start) {
	this.project_start = project_start;
}

public String getProject_end() {
	return project_end;
}

public void setProject_end(String project_end) {
	this.project_end = project_end;
}

public String getNo_of_emp() {
	return no_of_emp;
}

public void setNo_of_emp(String no_of_emp) {
	this.no_of_emp = no_of_emp;
}

public String getProject_manager() {
	return Project_manager;
}

public void setProject_manager(String project_manager) {
	Project_manager = project_manager;
}

public String getProject_hr() {
	return project_hr;
}

public void setProject_hr(String project_hr) {
	this.project_hr = project_hr;
}

public String getAssignedby() {
	return assignedby;
}

public void setAssignedby(String assignedby) {
	this.assignedby = assignedby;
}

public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public String getJoindate() {
	return joindate;
}

public void setJoindate(String joindate) {
	this.joindate = joindate;
}

public String getFirstname() {
	return firstname;
}

public void setFirstname(String firstname) {
	this.firstname = firstname;
}

public String getLastname() {
	return lastname;
}

public void setLastname(String lastname) {
	this.lastname = lastname;
}

public String getRole() {
	return role;
}

public void setRole(String role) {
	this.role = role;
}

public String getUsernam() {
	return usernam;
}

public void setUsernam(String usernam) {
	this.usernam = usernam;
}

public String getDob() {
	return dob;
}

public void setDob(String dob) {
	this.dob = dob;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getPhone() {
	return phone;
}

public void setPhone(String phone) {
	this.phone = phone;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getZip() {
	return zip;
}

public void setZip(String zip) {
	this.zip = zip;
}

public String getRoleid() {
	return roleid;
}

public void setRoleid(String roleid) {
	this.roleid = roleid;
}

public String getCheckuser() {
	return checkuser;
}

public void setCheckuser(String checkuser) {
	this.checkuser = checkuser;
}

public String getCheckpwd() {
	return checkpwd;
}

public void setCheckpwd(String checkpwd) {
	this.checkpwd = checkpwd;
}

}
