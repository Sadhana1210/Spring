package com.example.demo.usercheck;

public class User {
	private int empid;
 public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

private String fname,lname,user;

public String getFname() {
	return fname;
}

public void setFname(String fname) {
	this.fname = fname;
}

public String getLname() {
	return lname;
}

public void setLname(String lname) {
	this.lname = lname;
}

public String getUser() {
	return user;
}

public void setUser(String user) {
	this.user = user;
}
}
