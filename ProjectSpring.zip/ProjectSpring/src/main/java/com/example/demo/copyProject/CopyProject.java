package com.example.demo.copyProject;

public class CopyProject {
	private String checkuser,checkpwd,newproject_name,project_copy_id;

	public String getCheckuser() {
		return checkuser;
	}

	public void setCheckuser(String checkuser) {
		this.checkuser = checkuser;
	}

	public String getCheckpwd() {
		return checkpwd;
	}

	public void setCheckpwd(String checkpwd) {
		this.checkpwd = checkpwd;
	}

	public String getNewproject_name() {
		return newproject_name;
	}

	public void setNewproject_name(String newproject_name) {
		this.newproject_name = newproject_name;
	}

	public String getProject_copy_id() {
		return project_copy_id;
	}

	public void setProject_copy_id(String project_copy_id) {
		this.project_copy_id = project_copy_id;
	}

}
