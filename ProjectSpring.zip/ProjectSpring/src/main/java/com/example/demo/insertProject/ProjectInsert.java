package com.example.demo.insertProject;

public class ProjectInsert {
	private String project_id,project_name,descrption,project_start,
	project_end,no_of_emp,Project_manager,project_hr,assignedby,checkuser,checkpwd;

	public String getCheckuser() {
		return checkuser;
	}

	public String getProject_id() {
		return project_id;
	}

	public void setProject_id(String project_id) {
		this.project_id = project_id;
	}

	public String getProject_name() {
		return project_name;
	}

	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}

	public String getDescrption() {
		return descrption;
	}

	public void setDescrption(String descrption) {
		this.descrption = descrption;
	}

	public String getProject_start() {
		return project_start;
	}

	public void setProject_start(String project_start) {
		this.project_start = project_start;
	}

	public String getProject_end() {
		return project_end;
	}

	public void setProject_end(String project_end) {
		this.project_end = project_end;
	}

	public String getNo_of_emp() {
		return no_of_emp;
	}

	public void setNo_of_emp(String no_of_emp) {
		this.no_of_emp = no_of_emp;
	}

	public String getProject_manager() {
		return Project_manager;
	}

	public void setProject_manager(String project_manager) {
		Project_manager = project_manager;
	}

	public String getProject_hr() {
		return project_hr;
	}

	public void setProject_hr(String project_hr) {
		this.project_hr = project_hr;
	}

	public String getAssignedby() {
		return assignedby;
	}

	public void setAssignedby(String assignedby) {
		this.assignedby = assignedby;
	}

	public void setCheckuser(String checkuser) {
		this.checkuser = checkuser;
	}

	public String getCheckpwd() {
		return checkpwd;
	}

	public void setCheckpwd(String checkpwd) {
		this.checkpwd = checkpwd;
	}
}
