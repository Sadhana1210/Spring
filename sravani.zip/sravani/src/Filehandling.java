import java.io.file;
import java.io.IoException;
public class File{
public static void main(String[] args)throws IoException {
		file f = new file ("D:/home/miracle/Desktop");
		System.out.println(f.CreateNewfile());

	}

}
