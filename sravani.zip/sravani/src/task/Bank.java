package task;

public class Bank {

}
