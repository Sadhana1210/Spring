package jdbc;
import java.sql.*;
public class Jdbc2 {

	public static void main(String[] args)throws Exception{
		
		// TODO Auto-generated method stub
		Connection con=DriverManegr.getConnection("jdbc:mysql://loaclhost:3306","root","M1racle@123");
		PrepareadStatement s.con.PrapareStatement()

	}

}
