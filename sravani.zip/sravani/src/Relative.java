import java.io.File;
 public class file {
    public static void main(String[] args)throws IoException {
		File f = new file("./home/miracle");
		if(f.Exit())
			System.out.println(f.delete());
		    System.out.println(f.CreatNewFile());

	}
	
}
