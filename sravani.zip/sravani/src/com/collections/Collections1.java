package com.collections;
import java.util.*;
public class Collections1 {

	public static void main(String[] args){
		ArrayList<String> c1 = new ArrayList<String>();
		c1.add("Red");
		c1.add("pink");
		c1.add("Green");
		System.out.println("c1");
		}
}
