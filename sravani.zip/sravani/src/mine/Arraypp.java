package mine;

public class Arraypp {

	public static void main(String[] args) {
		 int A[]= {1,3,4,5};
		
		 int Ar[]= {3,2,3,2};
		 for(int a:A) {
			 
			 System.out.println(a);
		 }

A.toString();
for(int b:A) {
System.out.println(b);
	}
	}
}
