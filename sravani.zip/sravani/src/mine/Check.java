package mine;

public class Check {
public static void main(String[] args) {
	int a=-990;
	int b=0;
//	if(a>0) {
		b=a/2;
		b=b*2;
		
	
	if(a==b) {
		System.out.println("even");
	}
	else {
		System.out.println("odd");
	}
}
}
