package mine;

public class ConcateMiddle {
public static void main(String[] args) {
	String s="sadhana";
	String s1="sai";
	System.out.println(s.substring(0,3)+s1+s.substring(3,7));
	
}
}
