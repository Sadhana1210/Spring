package mine;

public class Checkequal {
public static void main(String args[]) {
	String s=new String("sadhana");
	String s1=new String("sadhana");
	System.out.println(s==s1);
//	String s3="sadhana";
//	String s2="sadhana";
//	System.out.println(s1.equals(s));
//	System.out.println(s1==s2);
//	System.out.println(s1==s);
//    class Checkequal{  
//    public static void main(String args[]){  
//      
//    for(int i=0;i<args.length;i++)  
//    System.out.println(args[i]); 
//    System.out.println("hi");
//      
//    }  
//    }  

}
}
