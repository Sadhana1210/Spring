package mine;

public class Div {
	public static void main(String[] args) {
double n=4;
double n1=12;
int count=0;
for(double i=n1;i>=0;i=i-n) {
	if(i<n) {
		System.out.println("qoutient"+count);
		System.out.println("remainder"+i);
	}
	count++;
	
}
}
}
