package sravani;
 public class ArrayList {
    public static void main(String[] args){
		// TODO Auto-generated method stub
		ArrayList <String> list = new ArrayList <String> ();
		list.add("Ravi");
		list.add("vijay");
		list.add("vinay");
		list.add("Ajay");
		iterator itr = list iterator();
   while(itr.HashNext)
		{
			System.out.println(itr.Next);
		}

	}
 }  